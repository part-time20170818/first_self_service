CREATE PROCEDURE sys.ps_setup_disable_thread(IN in_connection_id BIGINT)
  BEGIN UPDATE performance_schema.threads SET instrumented = 'NO' WHERE processlist_id = in_connection_id;  SELECT CONCAT('Disabled ', @rows := ROW_COUNT(), ' thread', IF(@rows != 1, 's', '')) AS summary; END;
